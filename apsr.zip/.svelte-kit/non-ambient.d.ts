
// this file is generated — do not edit it


declare module "svelte/elements" {
	export interface HTMLAttributes<T> {
		'data-sveltekit-keepfocus'?: true | '' | 'off' | undefined | null;
		'data-sveltekit-noscroll'?: true | '' | 'off' | undefined | null;
		'data-sveltekit-preload-code'?:
			| true
			| ''
			| 'eager'
			| 'viewport'
			| 'hover'
			| 'tap'
			| 'off'
			| undefined
			| null;
		'data-sveltekit-preload-data'?: true | '' | 'hover' | 'tap' | 'off' | undefined | null;
		'data-sveltekit-reload'?: true | '' | 'off' | undefined | null;
		'data-sveltekit-replacestate'?: true | '' | 'off' | undefined | null;
	}
}

export {};


declare module "$app/types" {
	type MatcherParam<M> = M extends (param : string) => param is (infer U extends string) ? U : string;

	export interface AppTypes {
		RouteId(): "/" | "/packages" | "/packages/seo-packages" | "/packages/website-packages" | "/services" | "/services/seo-growth" | "/services/web-design";
		RouteParams(): {
			
		};
		LayoutParams(): {
			"/": Record<string, never>;
			"/packages": Record<string, never>;
			"/packages/seo-packages": Record<string, never>;
			"/packages/website-packages": Record<string, never>;
			"/services": Record<string, never>;
			"/services/seo-growth": Record<string, never>;
			"/services/web-design": Record<string, never>
		};
		Pathname(): "/" | "/packages/seo-packages" | "/packages/website-packages" | "/services" | "/services/seo-growth" | "/services/web-design";
		ResolvedPathname(): `${"" | `/${string}`}${ReturnType<AppTypes['Pathname']>}`;
		Asset(): "/robots.txt" | string & {};
	}
}